import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router);
	
import bunding from 'components/bunding/bunding' ;
import bundingInfo from 'components/bunding/bundingInfo' ;
import unbunding from 'components/bunding/unbunding' 
import success from 'components/bunding/success' 
import {isEmpty} from 'src/common/js/unit';
import * as Global from 'src/common/js/global';
 
let router = new Router({

  linkActiveClass:'active',

  routes: [
     {
      
      path:'/',
      redirect: '/bunding'
      
      } 
     ,
     {
     	name:'bunding',
     	path:'/bunding',
     	component:bunding,
      beforeEnter: (to, from, next) => {
         if(!isEmpty(sessionStorage.OPNEID) && !isEmpty(sessionStorage.ECIFId))
         {
           next({name:'bundingInfo'});
           
         }else{
           next();
         }
         
      }
     },
     {
     	name:'bundingInfo',
     	path:'/bundingInfo',
     	component: bundingInfo,
      beforeEnter: (to, from, next) => {
         
         if(isEmpty(sessionStorage.ECIFId))
         {
           next({name:'bunding'});
         }else{
           next();
         }
           
      
        }
      },
      {
       	name:'unbunding',
       	path:'/unbunding',
       	component: unbunding,
        beforeEnter: (to, from, next) => {
           document.title='账户解绑'; 
           next();
        }
      },
      {
      name:'success',
      path:'/success',
      component: success
     },
  ]
});

 
 
router.beforeEach((to, from, next) => { 
      document.title='绑定/解绑';  
      if(isEmpty(sessionStorage.Code)){
         sessionStorage.Code = Global.Access.getLocationCode()
        
      }
      if(!isEmpty(sessionStorage.Code) && isEmpty(sessionStorage.OPNEID)){
              Global.Access.getOpenId(sessionStorage.Code, function(data){
                if (!isEmpty(data)) {
                  sessionStorage.OPNEID = data;
                  loadEcifId(function(){
                    next();
                  })
                }else{
                  next();
                }
              })
      }else{
        next()
      }
      
})
function loadEcifId(callback){
    
      if(isEmpty(sessionStorage.ECIFId)){
           
           Global.Access.getECIFId(sessionStorage.OPNEID, function(data){  
                if(data.flag.code==0){
                  if(!isEmpty(data.ecifId)){                 
                      sessionStorage.ECIFId = data.ecifId;
                      if (typeof callback === "function"){
                         + callback();  
                      }
                      
                  }
                }else if(data.flag.code==1){  
                      sessionStorage.ECIFId = '';
                      if (typeof callback === "function"){
                         + callback();  
                      }
                }
           })
         }
}
      
export default router;
